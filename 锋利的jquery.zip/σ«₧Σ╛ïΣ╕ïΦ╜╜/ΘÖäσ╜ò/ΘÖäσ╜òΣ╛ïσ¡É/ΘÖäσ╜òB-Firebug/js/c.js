if( document.getElementById("c") ){
     	document.getElementById("c").innerHTML = " c ";
}